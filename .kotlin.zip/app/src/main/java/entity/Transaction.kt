package entity

class Transaction(var id: Int, var type: String, var details: String, var value: Double, var date: String)
